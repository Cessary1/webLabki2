export interface Vacancy {
    id: number;
    name: string;
    description: string;
    salary: string;
    company: number;
}