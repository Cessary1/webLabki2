package lab1;
import java.util.Scanner;

public class task6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter word:");
		Scanner input = new Scanner(System.in);
		
		String s = input.nextLine();
		int counter = 0;
		for(int i=0;i<s.length()/2; i++)
		{
			if(s.charAt(i) == s.charAt(s.length()-i-1))
				counter++;
		}
		
		if(counter == s.length()/2)
			System.out.println("Palindrome");
		else
			System.out.println("Not palindrome");
	}

}
