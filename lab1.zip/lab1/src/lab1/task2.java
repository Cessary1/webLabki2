package lab1;

import java.util.Scanner;
import java.lang.Math; 

public class task2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner (System.in);
		System.out.println("Enter side length");
		double a = input.nextDouble();
		double area = a*a;
		double perimeter = 4*a;
		double diagonal = a*Math.sqrt(2.0);
		System.out.println("Area: " + area + " Perimeter: " + perimeter + " Diagonal: " + diagonal);
	}

}
