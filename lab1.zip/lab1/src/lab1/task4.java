package lab1;
import java.util.Scanner;
import java.lang.Math;

public class task4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter number a");
		double a = input.nextDouble();
		System.out.println("Enter number b");
		double b = input.nextDouble();
		System.out.println("Enter number c");
		double c = input.nextDouble();
		
		double d = b*b - 4*a*c;
		
		System.out.println(d);
		System.out.println(-b);
		if(d<0)
			System.out.println("No answer");
		else if (d==0)
			System.out.println(-b/2*a);
		else 
		{
			double answer1 = (-b - Math.sqrt(d))/ 2*a;
			double answer2 = (-b + Math.sqrt(d))/2*a;
			System.out.println("Fisrt: " + answer1);
			System.out.println("Second: " + answer2);
		}
			
	}

}
