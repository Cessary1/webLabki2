package lab1;
import java.util.Scanner;
import java.lang.Math;
public class task5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter time in years");
		int time = input.nextInt();
		int initial = 10000;
		double interest = 0.1;
		
		
		double balance = initial * Math.pow((1+interest),time);
		System.out.println(balance);
		
	}

}
