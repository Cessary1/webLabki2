package lab1;

import java.util.Scanner;

public class task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter number");
		
		Scanner input = new Scanner(System.in);
		
		int number = input.nextInt();
		
		if(number>=95 && number <=100)
			System.out.println("A");
		else if(number<95 && number >=90)
			System.out.println("A-");
		else if(number<90 && number >=85)
			System.out.println("B+");
		else if(number<85 && number >=80)
			System.out.println("B");
		else if(number<80 && number >=75)
			System.out.println("B-");
		else if(number<75 && number >=70)
			System.out.println("C+");
		else if(number<70 && number >=65)
				System.out.println("C");
		else if(number<65 && number >=60)
			System.out.println("C-");
		else if(number<60 && number >=55)
			System.out.println("D+");
		else if(number<50 && number >=45)
			System.out.println("D");
		else if(number<45 && number >=40)
			System.out.println("D-");
		else if(number<40)
			System.out.println("F");
		else 
			System.out.println("Number out of range");
	}

}
