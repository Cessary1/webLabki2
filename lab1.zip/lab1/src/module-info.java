module lab1 {

}