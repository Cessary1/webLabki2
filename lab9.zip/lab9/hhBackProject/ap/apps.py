from django.apps import AppConfig


class ApConfig(AppConfig):
    name = 'ap'
