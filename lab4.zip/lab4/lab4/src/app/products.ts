export const products = [
  {
    name: '3 шт полное покрытие стекло для iPhone X XS Max XR',
    imageLink: 'https://ae01.alicdn.com/kf/HTB13nYVelWD3KVjSZFsq6AqkpXaA/3-iPhone-X-XS-Max-XR.jpg', 
    price: "181 руб",
    description: 'A large phone with one of the best screens',
    rating: 4.9,
    link: 'https://aliexpress.ru/item/33022282524.html?spm=a2g0o.productlist.0.0.18841402x7xCoi&algo_pvid=f8000509-835b-422d-b48c-3062489b6b8f&algo_expid=f8000509-835b-422d-b48c-3062489b6b8f-0&btsid=3069d295-6f57-47b8-9ab6-87fc2e156206&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Закаленное стекло для samsung Galaxy A50 A30',
    imageLink: 'https://ae01.alicdn.com/kf/HTB1taipcA9E3KVjSZFGq6A19XXa2/samsung-Galaxy-A50-A30.jpg', 
    price: "176 руб",
    description: 'Закаленное стекло для samsung Galaxy A50 A30 Защитное стекло для экрана для samsung Galaxy A10 M20 M30 A20 A20E A40 A80 A70 A60 стекло',
    rating: 4.8,
    link: 'https://aliexpress.ru/item/33022807714.html?spm=a2g0o.productlist.0.0.18841402x7xCoi&algo_pvid=f8000509-835b-422d-b48c-3062489b6b8f&algo_expid=f8000509-835b-422d-b48c-3062489b6b8f-1&btsid=3069d295-6f57-47b8-9ab6-87fc2e156206&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Ugreen Micro USB Кабель 2.4A ',
    imageLink: 'https://ae01.alicdn.com/kf/Hfd5626ca1e5b4a8d88d9d6923ce326ecQ/Ugreen-Micro-USB-2-4A-USB.jpg', 
    price: "309 руб",
    description: 'Провод для Быстрой Зарядки для Samsung s Huawei Xiaomi HTC LG Планшет Android зарядное устройство для телефона Кабель Micro USB',
    rating: 4.9,
    link: 'https://aliexpress.ru/item/32391749504.html?spm=a2g0o.productlist.0.0.443875f8M7Hbu1&s=p&algo_pvid=297a27a7-4341-4b59-ba37-cce459ab5ff9&algo_expid=297a27a7-4341-4b59-ba37-cce459ab5ff9-0&btsid=a1ada2e2-479c-43d1-9307-ae2830921c39&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Круглый Магнитный кабель',
    imageLink: 'https://ae01.alicdn.com/kf/H75645f00128541e3921f4957f6e6357bN/C-Micro-USB.jpg', 
    price: "59 руб",
    description: 'Зарядка адаптер телефонный кабель Microusb Тип-C магнит Зарядное устройство штепсельной вилки',
    rating: 4.8,
    link: 'https://aliexpress.ru/item/4000308733181.html?spm=a2g0o.productlist.0.0.443875f8M7Hbu1&s=p&algo_pvid=297a27a7-4341-4b59-ba37-cce459ab5ff9&algo_expid=297a27a7-4341-4b59-ba37-cce459ab5ff9-5&btsid=a1ada2e2-479c-43d1-9307-ae2830921c39&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Высококачественные мужские часы',
    imageLink: 'https://ae01.alicdn.com/kf/H3e11f568c2034d2ca7d1a6d795cff4f02/-.jpg', 
    price: "29 730 руб",
    description: 'Высококачественные мужские часы с прозрачным каркасом, турбийон, оригинальные турбийон, с ручным заводом',
    rating: 5.0,
    link: 'https://aliexpress.ru/item/4000406704706.html?spm=a2g0o.productlist.0.0.445971815wP6UC&s=p&algo_pvid=8e7bcad0-eb62-4cbd-9f11-41aa74bbf5f5&algo_expid=8e7bcad0-eb62-4cbd-9f11-41aa74bbf5f5-0&btsid=7ed6eed8-d439-42ee-b00b-54a08fbe58d9&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Настенный Гобелен',
    imageLink: 'https://ae01.alicdn.com/kf/H3378790393b2496dbf69a847b1a95061p/-.jpg', 
    price: "672 руб",
    description: 'Богемный шик макраме Настенный Гобелен Мандала Луна Ловец снов на стену Декор',
    rating: 5.0,
    link: 'https://aliexpress.ru/item/4000500726711.html?spm=a2g0o.productlist.0.0.3ab57b7aRHziKn&algo_pvid=fa3cda5b-2ff0-43cb-b37e-70e694014db2&algo_expid=fa3cda5b-2ff0-43cb-b37e-70e694014db2-8&btsid=7d8cf5f9-aebe-4e4f-9411-d6d91ff36b56&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Винтажные женские сумки',
    imageLink: 'https://ae01.alicdn.com/kf/HTB1qFwcie3tHKVjSZSgq6x4QFXa0/-.jpg', 
    price: "681 руб",
    description: 'Винтажные женские сумки из нубука, женские сумки через плечо с верхней ручкой, меховая подвеска, сумка через плечо',
    rating: 3.0,
    link: 'https://aliexpress.ru/item/4000155824718.html?spm=a2g0o.productlist.0.0.694b4e09lk8f1C&algo_pvid=cf8abec0-f275-48c0-ba7d-2297b730aca2&algo_expid=cf8abec0-f275-48c0-ba7d-2297b730aca2-12&btsid=05de6b66-eb76-4e75-b045-8dfe586fed61&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Пластиковые прозрачные бутылки',
    imageLink: 'https://ae01.alicdn.com/kf/H6c4ec0dbe28d43a185a06af1fd9aa8458/8.jpg', 
    price: "170 руб",
    description: '8 шт./компл. пластиковые прозрачные бутылки для многоразового использования мини набор косметики',
    rating: 4.8,
    link: 'https://aliexpress.ru/item/4000134453143.html?spm=a2g0o.productlist.0.0.694b4e09lk8f1C&algo_pvid=cf8abec0-f275-48c0-ba7d-2297b730aca2&algo_expid=cf8abec0-f275-48c0-ba7d-2297b730aca2-11&btsid=05de6b66-eb76-4e75-b045-8dfe586fed61&ws_ab_test=searchweb0_0,searchweb201602_6,searchweb201603_53'
  },
  {
    name: 'Фетровые облака',
    imageLink: 'https://ae01.alicdn.com/kf/HTB1Ft7vaBKw3KVjSZFOq6yrDVXa5/-.jpg', 
    price: "320 руб",
    description: 'В скандинавском стиле симпатичные фетровые облака форма настенный орнамент деревянная палка кисточка Подвеска',
    rating: 4.8,
    link: 'https://aliexpress.ru/item/33025448981.html?spm=a2g01.12375326.layer-is9wlp.2.17a967d0VutViQ&gps-id=5895473&scm=1007.20780.155586.0&scm_id=1007.20780.155586.0&scm-url=1007.20780.155586.0&pvid=d0678510-1050-4b28-843d-8841230224c0'
  },
  {
    name: 'Пластиковые прозрачные бутылки',
    imageLink: 'https://ae01.alicdn.com/kf/H5cdb85d06d4648428d8048ded8dfce32i/-.jpg', 
    price: "198 руб",
    description: 'Можно повесить полотенце кораллового цвета Полотенце кухонное чистящее полотенце',
    rating: 5.0,
    link: 'https://aliexpress.ru/item/4000354898661.html?spm=a2g0v.best.6.8.4375SXCqSXCqgu&scm=1007.17258.156125.0&pvid=27f90d06-0691-4abd-b568-ade8eca41abb'
  },
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/