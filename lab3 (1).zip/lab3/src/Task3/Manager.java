package Task3;

import java.util.Vector;

public class Manager extends Employee {

	Vector <Employee> employes = new Vector <Employee>();
	int bonus = 0;
	
	public Manager() {super();};
	
	public Manager(String name) {super(name);};
	
	public Manager(int bonus) {this.bonus = bonus;};
	
	public Manager(Vector <Employee> employes) {
		this();
		this.employes = employes;
	};
	
	public Manager(String name, int bonus) {
		this(name);
		this.bonus = bonus;
	};
	
	public Manager(String name, int bonus, Vector <Employee> employes) {
		this(name, bonus);
		this.employes = employes;
	};
	
	public Manager(String name, double salary) {
		super(name, salary);
	};
	
	public Manager(String name, double salary, int yearOfWork) {
		super(name, salary, yearOfWork);
	};
	
	public Manager(String name, double salary, int yearOfWork,String insuranceNumber) {
		super(name, salary, yearOfWork, insuranceNumber);
	};
	
	public Manager(String name, double salary, int yearOfWork,String insuranceNumber, int bonus) {
		super(name, salary, yearOfWork, insuranceNumber);
		this.bonus = bonus;
	};
	

	public Manager(String name, double salary, int yearOfWork,String insuranceNumber, int bonus
			,Vector <Employee> employes) {
		super(name, salary, yearOfWork, insuranceNumber);
		this.bonus = bonus;
		this.employes = employes;
	};
	
	
	
	
	
	public int getBonus() {
		return this.bonus;
	}
	public Vector <Employee> getEmployes() {
		return this.employes;
	}
	
	
	
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	public void setEmployes(Vector <Employee> employes) {
		this.employes = employes;
	}
	
	@Override
	public String toString() {
		return super.toString() + " Bonus: " + this.bonus + " Employes: " + this.employes;  
	};
	
	public boolean equals() {
		return super.equals(this);
	};
	
	public int hashCode() {
		return super.hashCode();
	}
}
