package Task3;

public class Employee extends Person {
	String name = super.name;
	double salary = 0;
	int yearOfWork = 1000;
	String insuranceNumber = "No Insurance";
	
	
	public Employee() {super();};
	
	public Employee(String name) {super(name);};
	
	public Employee(String name, double salary) {
		this(name);
		this.salary = salary;
	};
	
	public Employee(String name, double salary, int yearOfWork) {
		this(name, salary);
		this.yearOfWork = yearOfWork;
	};
	
	public Employee(String name, double salary, int yearOfWork,String insuranceNumber) {
		this(name, salary, yearOfWork);
		this.insuranceNumber = insuranceNumber;
	};
	
	
	
	public String getName() {
		return this.name;
	}
	public double getSalary() {
		return this.salary;
	}
	public int getYearOfWork() {
		return this.yearOfWork;
	}
	public String getInsuranceNumber() {
		return this.insuranceNumber;
	}
	
	
	
	public void setName(String name) {
		this.name = name;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setYearOfWork(int yearOfWork) {
		this.yearOfWork = yearOfWork;
	}
	public void setInsuranceNumber(String insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}
	
	
	
	@Override
	public String toString() {
		return super.toString() + " Salary: " + this.salary + " YearOfWork: " + this.yearOfWork + " insuranceNumber: " + this.insuranceNumber;  
	};
	
	public boolean equals() {
		return super.equals(this);
	};
	
	public int hashCode() {
		return super.hashCode();
	}
}
