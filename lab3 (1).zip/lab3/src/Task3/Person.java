package Task3;

public class Person {
	public String name;
	public Person() {};
	public Person(String name) {
		this.name = name;
	}
	
	public String toString() {
		return "Name: " + this.name;
	}
	
	public boolean equals(Person p) {
		if(p == null ||(p.getClass()!=this.getClass())) {
			return false;
		}
		return true;
	}
	
	public int hashCode() {
		int result = 31 * 17 + this.name.length();
		return result;
	}
}
