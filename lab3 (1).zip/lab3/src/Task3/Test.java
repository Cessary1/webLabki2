package Task3;

import java.util.Vector;
import java.util.*;

public class Test {

	public static void main(String[] args) {
		
		Vector <Employee> employes = new Vector <Employee>();
		HashSet<Employee> distinctEmp = new HashSet<Employee>();
		
		Employee e1 = new Employee("Aidos");
		e1.setSalary(10000.0);
		e1.setYearOfWork(2018);
		e1.setInsuranceNumber("17AAA");
		
		Employee e2 = new Employee("Adina", 100330.0, 2016, "17BBB");
		
		employes.add(e1);
		employes.add(e2);
		
		Manager m = new Manager("Aidana", 5);
		m.setEmployes(employes);
		System.out.println(m);
		
		distinctEmp.add(e1);
		distinctEmp.add(e1);
		
		System.out.println(distinctEmp);
	}

}
