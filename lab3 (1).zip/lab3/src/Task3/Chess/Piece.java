package Task3.Chess;

public class Piece {
}
