package lab3.Task1;

public abstract class Animal {
	
	public String name;
	public Animal() {
		name = "noName";
	}
	
	public Animal(String name) {
		this.name = name;
	}
	
	public String getName(Animal a) {
		return a.name;
	}
	
	public abstract void  makeSound();
}
