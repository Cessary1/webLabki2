package lab3.Task1;

public class Cat extends Animal {
	public Cat() {
		super();
	}
	
	public Cat(String name) {
		super(name);
	}
	
	public String getName(Cat c) {
		return c.name;
	}
	
	@Override
	public void makeSound() {
		System.out.println("Meow");
	}
	
}
