package lab3.Task1;

public class Dog extends Animal {
	public Dog() {
		super();
	}
	
	public Dog(String name) {
		super(name);
	}
	
	public String getName(Dog d) {
		return d.name;
	}
	
	@Override
	public void makeSound() {
		System.out.println("Bark");
		
	}
}
