package lab3.Task2;

public class Sphere  extends Figure{
	
	private int radius;
	public Sphere() {
		
	}
	
	public Sphere(int raduis) {
		this.radius = raduis;
	}
	
	 @Override
	 public double volume() {
		 return (Math.PI*(this.radius^3)*4)/3;
	 }
	 public double surfaceArea() {
		 return 4*Math.PI*this.radius* this.radius;
	 }
}
