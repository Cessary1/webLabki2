package lab3.Task2;
import java.math.*;

public class Cylinder extends Figure {
	private int radius;
	private int height;
	public Cylinder() {
		
	}
	
	public Cylinder(int raduis, int height) {
		this.height = height;
		this.radius = raduis;
	}
	 @Override
	 public double volume() {
		 return Math.PI*this.radius*this.height;
	 };
	 public double surfaceArea() {
		 return Math.PI*this.radius*this.height*2 + 2*Math.PI*this.radius* this.radius;
	 };
}
