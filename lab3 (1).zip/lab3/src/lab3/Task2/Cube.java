package lab3.Task2;

public class Cube extends Figure {

	private int edge;
	public Cube() {
		
	}
	
	public Cube(int edge) {
		this.edge = edge;
	}
	
	 @Override
	 public double volume() {
		 return this.edge^3;
	 }
	 public double surfaceArea() {
		 return 6*this.edge* this.edge;
	 }
	 
}
