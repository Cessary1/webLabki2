package lab3.Task2;

public abstract class Figure {
	public Figure() {};
	
	public abstract double volume();
	public abstract double surfaceArea();
}
