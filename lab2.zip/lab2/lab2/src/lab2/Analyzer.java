package lab2;
import java.util.Scanner;

public class Analyzer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		Data data = new Data();
		while (true) {
			System.out.println("Enter Number (Q to quit): ");
			String input = scanner.next();
			if(input.equals("Q")) {
				break;
			}
			else {
				data.addData(Integer.parseInt(input));
			}
		}
		
		System.out.println("Average: " + data.average());
		System.out.println("Maximum: " + data.max());
	}

}
