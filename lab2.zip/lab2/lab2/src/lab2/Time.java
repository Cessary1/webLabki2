package lab2;

public class Time {

	int hour;
	int minute;
	int second;
	
	public Time(int hour, int minute, int second) {
		if( 0<hour && hour<25 && 0<=minute && minute<=60 && 0<=second && second<=60) {
			this.hour = hour;
			this.minute = minute;
			this.second = second;
		}
		else {
			System.out.println("Invalid time input");
		}
	}
	
	public String toUniversal() {
		String universalTime = String.format("%02d", this.hour) + ":" + String.format("%02d", this.minute) + ":" + String.format("%02d", this.second);
		return universalTime;
	}
	
	public String toStandart() {
		String standartTime;
		if(this.hour<=12) {
			standartTime = this.toUniversal() + " AM";
		}
		else {
			this.hour -= 12;
			standartTime = this.toUniversal() + " PM";
		}
		return standartTime;
	}
	
	public Time add(Time t) {
		this.second += t.second;
		if(this.second>60) {
			this.second -= 60;
			this.minute += 1;
		}
		
		this.minute += t.minute;
		if(this.minute>60) {
			this.minute -= 60;
			this.hour += 1;
		}
		
		this.hour += t.hour;
		if(this.hour>24) {
			this.hour -= 24;
		}
		
		return this;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Time t = new Time(13,5,10);
		System.out.println(t.toUniversal());
		System.out.println(t.toStandart());
		Time t2 = new Time(5,57,57);
		System.out.println(t2.toUniversal());
		System.out.println(t2.toStandart());
		System.out.println(t.add(t2).toUniversal());
	}

}
