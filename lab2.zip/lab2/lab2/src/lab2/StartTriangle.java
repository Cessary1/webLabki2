package lab2;

public class StartTriangle {
	public int width;
	
	public StartTriangle(int width) {
		this.width = width;
	}
	
	public String toString() {
		String triangle = "";
		for(int i = 0;i<this.width;i++) {
			for(int j=1;j<=i+1;j++)
			{
				triangle += "[*]";
			}
			triangle+="\n";
		}
		return triangle;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StartTriangle small = new StartTriangle(3);
		System.out.println(small.toString());
	}

}
