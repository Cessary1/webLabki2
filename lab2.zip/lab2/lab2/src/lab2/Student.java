package lab2;

public class Student {

	public String name;
	public String id;
	public int yos = 1;
	
	public Student(String name, String id) {
		this.name = name;
		this.id = id;
	}
	
	public int incrementYearOfStudy(){
		yos+=1;
		return yos;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getID() {
		return this.id;
	}
	
	public int getYos() {
		return this.yos;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student = new Student("Kiori", "18BD110250");
		System.out.println(student.getName() + " " + student.getID() + " " + student.getYos());
		student.incrementYearOfStudy();
		System.out.println(student.getName() + " " + student.getID() + " " + student.getYos());
	}

}
