package lab2;

public class Worker {
	
	public enum Gender {
	    Male,
	    Female,
	}
	
	int id = 0;
	String name;
	String surname;
	Gender gender;
	int workingTableNumber;
	int salary;
	static int numberOfWorkers = 5; //one for all class representatives
	static final String officeLocation = "Tole Bi,36"; 
	static final int hoursOfWork = 8; //final variable, will not be changed
	
	
	private static int nextId = 0;
	
	{
		id = nextId++; //initialization block
	}
	
	public int getSalary() {return this.salary; }; //read-only methods
	public int getId() {return this.id; };
	
	public Worker(String name, String surname, Gender gender) {
		this.name = name; //used to invoke another constructor in the same class
		this.surname = surname;
		this.gender = gender;
	}
	
	public void setWorkingPlace(int number) { //method overloading
		this.workingTableNumber = number;
	}
	
	public void setWorkingPlace(Worker w) {
		this.workingTableNumber = w.workingTableNumber + 1;
	}
	
	public void print() {
		System.out.println("ID:" + this.id + " Name:" + this.name + " Surname:" + this.surname + " Gender:" + this.gender
				+ " Salary:" + this.salary + " OfficeLocation:" + Worker.officeLocation + " TableNumber:" + this.workingTableNumber + 
				" HoursOfWork:" + Worker.hoursOfWork + " NumberOfWorkers:" + Worker.numberOfWorkers);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gender m = Gender.Male;
		Gender f = Gender.Female;
		Worker w1 = new Worker("Kiori", "Kim", f);
		Worker w2 = new Worker("Astam", "Kurbanov", m);
		w1.setWorkingPlace(1);
		w2.setWorkingPlace(w1);
		w1.print();
		w2.print();
	}

}
