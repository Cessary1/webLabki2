package lab2;

public class Data {

	private double sum = 0;
	private double max = -1000;
	private int counter = 0;
	
	public Data() {};
	
	void addData(int number) {
		sum+=number;
		counter++;
		if(number>max) {
			max = number;
		}
	}
	
	double average() {
		double average = this.sum/this.counter;
		return average;
	}
	
	double max() {
		return this.max;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
