module lab2 {
}