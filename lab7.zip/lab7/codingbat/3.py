def sum_double(a, b):s
  sum = a + b
  if a == b:
    sum = sum * 2
  return sum