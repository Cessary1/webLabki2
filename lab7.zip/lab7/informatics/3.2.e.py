import math
a = int(input())
print(math.ceil(math.log(a, 2)))