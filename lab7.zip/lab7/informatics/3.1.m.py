sum = 0
r = int(input())
for x in range (1, r+1):
    a = int(input())
    if a==0:
        sum+=1
print(sum)