import math
a = int(input())
b = int(input())
c = math.sqrt(a*a + b*b)
print(c)