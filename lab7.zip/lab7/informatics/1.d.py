a = int(input())
b = int(input())
print(b - int(b/a)*a)