sum = 0
for x in range (1, 101):
    a = input()
    sum += int(a)
print(sum)