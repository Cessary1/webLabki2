def pw(a,b):
    result = 1
    for i in range(b):
        result *=a 
    return result
pw(2,4)