a = int(input())
b = []
sum = 0
for i in range(a):
    b.append(int(input()))
b.reverse()
print(b)