def fm (a,b,c,d):
    array = [a,b,c,d]
    array.sort()
    return array[0]
print(fm(0,1,2,3))