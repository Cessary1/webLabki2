a = int(input())
b = []
for i in range(a):
    b.append(int(input()))
print(b[0::2])