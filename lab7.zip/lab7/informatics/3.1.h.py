a = int(input())
i = 2
for x in range (1, a+1):
    if a%x == 0:
        print(x)
