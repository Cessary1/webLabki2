a = int(input())
i = 1
print(i)
while 2**i <=a:
    print(2**i)
    i+=1