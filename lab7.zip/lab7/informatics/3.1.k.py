sum = 0
r = int(input())
for x in range (1, r+1):
    a = input()
    sum += int(a)
print(sum)