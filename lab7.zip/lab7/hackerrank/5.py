a = int(input())
for x in range(0, a): 
    print(x*x)